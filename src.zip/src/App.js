

import VideoApp from './VideoApp';

function App() {
  return (
    <div className="App">
      <VideoApp/>
    </div>
  );
}

export default App;
